"""Pacote de cliente da integração com Control iD.

Este pacote expõe o :class:`~controlid_system.client.controlid_client.ControlIDClient` para
interagir programaticamente com equipamentos da linha de acesso Control iD.
"""

from .controlid_client import ControlIDClient, ControlIDError  # noqa: F401

__all__ = ["ControlIDClient", "ControlIDError"]